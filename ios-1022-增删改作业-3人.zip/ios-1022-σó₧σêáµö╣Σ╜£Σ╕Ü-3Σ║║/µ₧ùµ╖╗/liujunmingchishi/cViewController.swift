//
//  cViewController.swift
//  liujunmingchishi
//
//  Created by Apple on 2019/10/8.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class cViewController: UIViewController {

    @IBOutlet weak var text1: UITextField!
    @IBOutlet weak var text2: UITextField!
    var foodForEdit: food?
    override func viewDidLoad() {
        super.viewDidLoad()
   self.text1.text=foodForEdit?.a
        self.text2.text=foodForEdit?.b
        self.navigationItem.title=foodForEdit?.a
        // Do any additional setup after loading the view.
    }
    
    @IBAction func re(_ sender: Any) {
    
    }
    
    @IBOutlet weak var a: UITextField!
    
    
    @IBAction func b(_ sender: Any) {
    
    }
    
    @IBAction func s(_ sender: Any) {
        self.dismiss(animated: false, completion: nil)
        print("dasda")
    }
    @IBAction func a(sender: UIStoryboardSegue) {
        print("a")
    }
    
    
  
    
   
    
    
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        if segue.identifier=="savetolist"{
            print("save")
            if(text1.text==""&&text2.text=="")
            {
            }
            else{
            foodForEdit=food(name:self.text1.text!,description: self.text2.text!)
                
            }
            
        }
        if segue.identifier=="canceltolist"{
            print("cancel")
            
    
        }
        // Pass the selected object to the new view controller.
    }
 

}
