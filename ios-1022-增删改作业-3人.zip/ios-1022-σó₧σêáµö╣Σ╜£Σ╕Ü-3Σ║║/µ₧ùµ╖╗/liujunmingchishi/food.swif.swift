//
//  food.swif.swift
//  liujunmingchishi
//
//  Created by Apple on 2019/10/15.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation
class food: NSObject,NSCoding {
    func encode(with aCoder: NSCoder) {
    aCoder.encode(a,forKey: "namekey")
        aCoder.encode(b,forKey: "descriptionkey")
    }
    
    required init?(coder aDecoder: NSCoder) {
        a=aDecoder.decodeObject(forKey: "namekey")as? String
        b=aDecoder.decodeObject(forKey: "descriptionkey")as? String
    }
    
    var a:String?
    var b: String?
    static let DocumentsDirectory=FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    static let ArchiveURL=DocumentsDirectory.appendingPathComponent("foodlist")
    
    init(name:String?,description:String?) {
        self.a=name
        self.b=description
    }
}
