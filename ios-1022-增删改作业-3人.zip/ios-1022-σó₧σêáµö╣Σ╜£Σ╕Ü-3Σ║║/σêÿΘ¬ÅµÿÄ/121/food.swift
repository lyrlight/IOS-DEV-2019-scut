//
//  food.swift
//  121
//
//  Created by Apple on 2019/10/15.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation
class Food: NSObject, NSCoding{
    func encode(with aCoder: NSCoder) {
        aCoder.encode(name,forKey: "namKey")
        aCoder.encode(des,forKey: "descriptionKey")
    }
    required init?(coder aDecoder: NSCoder) {
        name = aDecoder.decodeObject(forKey: "namKey") as? String
        des = aDecoder.decodeObject(forKey: "descriptionKey") as? String
    }
    
    var name: String?
    var des: String?
    init(name: String?, des: String?) {
        self.name = name
        self.des = des
    }
    static let DocumetsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    static let ArchiveURL = DocumetsDirectory.appendingPathComponent("foodList")
}
