//
//  ViewController.swift
//  222
//
//  Created by Apple on 2019/9/24.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func failToHere(sender: UIStoryboardSegue) {
    }
    @IBOutlet weak var welcome: UILabel!
    @IBOutlet weak var input1: UITextField!
    @IBOutlet weak var input2: UITextField!
    @IBOutlet weak var hint: UILabel!
    @IBAction func button1(_ sender: Any) {
    
    if let username = input1.text{
        welcome.text = "welcome " + username
        }
        if((input1.text == "ljm")&&(input2.text == "111")){
            hint.isHidden = false
            hint.backgroundColor = UIColor.green
            hint.text = "login successfully"
        }
        else {
            welcome.isHidden = true
            hint.isHidden = false
            hint.backgroundColor = UIColor.red
            hint.text = "login fail"
        }
    }
    @IBAction func button2(_ sender: Any) {
        if((input1.text != nil) && (input2 != nil)){
            hint.isHidden = false
            hint.backgroundColor = UIColor.green
            hint.text = "registered successfully"
        }
        else{
            hint.isHidden = false
            hint.backgroundColor = UIColor.green
            hint.text = "register fail"
        }
        
    }
}

