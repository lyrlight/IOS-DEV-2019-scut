//
//  ViewController.swift
//  lyr1234
//
//  Created by Apple on 2019/9/24.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var Label1: UILabel!
    
    @IBOutlet weak var Label2: UILabel!
    
    @IBOutlet weak var Label3: UILabel!
    
    @IBOutlet weak var Label4: UILabel!
    
    @IBOutlet weak var Label5: UILabel!
    
    @IBOutlet weak var Label6: UILabel!
    
    @IBOutlet weak var Label7: UILabel!
    
    @IBOutlet weak var Label8: UILabel!
    
    @IBOutlet weak var nameText: UITextField!
    
    @IBOutlet weak var passwordText: UITextField!
    
    @IBAction func Login(_ sender: Any) {
        if(nameText.text == "LYR"){
        if(passwordText.text == "123"){
            Label8.text = "欢迎" + nameText.text!
                Label5.isHidden = false
            Label7.isHidden = true
            Label6.isHidden = true
            }
        else{
            Label8.text = ""
            Label7.isHidden = false
            Label6.isHidden = false
            Label5.isHidden = true
            }
        }
        else{
            Label8.text = ""
            Label5.isHidden = true
            Label7.isHidden = false
            Label6.isHidden = false
        }
        
        
    }
    
    @IBAction func abcd(segue: UIStoryboardSegue){
        
    }
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

