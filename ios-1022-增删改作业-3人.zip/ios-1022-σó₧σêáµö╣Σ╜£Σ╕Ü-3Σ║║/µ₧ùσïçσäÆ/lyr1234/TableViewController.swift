//
//  TableViewController.swift
//  lyr1234
//
//  Created by Apple on 2019/10/15.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {
    var phoneList: [PhoneCell] = [PhoneCell]()
    
    func initPhoneList(){
        phoneList = loadPhoneFile()!
        if(phoneList.count == 0){
        phoneList.append(PhoneCell(name: "linyongru", phoneNumber: "15918870867"))
        phoneList.append(PhoneCell(name: "caps", phoneNumber: "110"))
        }


    }
    
    func savePhoneFile(){
        let success = NSKeyedArchiver.archiveRootObject(phoneList, toFile: PhoneCell.ArchiveURL.path)

        if !success {
            print("failed")
        }
    }
    func loadPhoneFile() ->[PhoneCell]? {
        return (NSKeyedUnarchiver.unarchiveObject(withFile: PhoneCell.ArchiveURL.path) as? [PhoneCell])
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initPhoneList()
    
        // self.clearsSelectionOnViewWillAppear = false
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    @IBAction func cancelToList(segue: UIStoryboardSegue){
        
    }

    @IBAction func saveToList (segue:UIStoryboardSegue){

        if let addNameVC = segue.source as? newViewController{
            if let addName = addNameVC.nameForEdit{
                if let selectedIndexPath = tableView.indexPathForSelectedRow{
                phoneList[(selectedIndexPath as NSIndexPath).row] = addName
                    tableView.reloadRows(at: [selectedIndexPath], with: .none)
                }
                else{
                    phoneList.append(addName)
                let newIndexPath = IndexPath(row: phoneList.count-1,section: 0)
                tableView.insertRows(at: [newIndexPath], with: .automatic)
            }
                savePhoneFile()
        }
    }
     
        
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return phoneList.count
        
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "phoneCell", for: indexPath)
        cell.textLabel?.text = phoneList[indexPath.row].name
        cell.detailTextLabel?.text = phoneList[indexPath.row].phoneNumber
        return cell
    }


    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            phoneList.remove(at: indexPath.row)
            savePhoneFile()
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
   

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "Show"){
        let phoneNumberVC = segue.destination as! newViewController
        if let selectedCell = sender as? UITableViewCell{
            let indexPath = tableView.indexPath(for: selectedCell)
            let selectedName = phoneList[(indexPath as! NSIndexPath).row]
            phoneNumberVC.nameForEdit = selectedName
        }
        print("Show")
    
        }
        if(segue.identifier == "Add"){
            print("Add")
            
        }
}
}
