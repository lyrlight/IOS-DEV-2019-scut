//
//  newViewController.swift
//  lyr1234
//
//  Created by Apple on 2019/10/15.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class newViewController: UIViewController {

    @IBOutlet weak var nameText: UITextField!
    @IBOutlet weak var numberText: UITextField!
    var nameForEdit: PhoneCell?
    
    override func viewDidLoad() {
        self.nameText.text = nameForEdit?.name
        self.numberText.text = nameForEdit?.phoneNumber
        self.navigationItem.title = nameForEdit?.name
        super.viewDidLoad()
    }
    

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.identifier == "saveToList"){
           
            print("save")
            nameForEdit = PhoneCell(name: self.nameText.text!,phoneNumber:  self.numberText.text!)
            
        }
       else if (segue.identifier == "cancelToList"){
            print("cancel")
            
        }

 
    }
  

}
