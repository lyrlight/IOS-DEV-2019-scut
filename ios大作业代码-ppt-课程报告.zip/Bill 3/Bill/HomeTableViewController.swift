//
//  HomeTableViewController.swift
//  Bill
//
//  Created by Apple on 2019/11/5.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class HomeTableViewController: UITableViewController{

    
    var dayList: [BillCell] = [BillCell]()
    func initDayList(){
       let list = loadPhoneFile()
        if(list == nil){
            dayList = [BillCell]()
        }else{
            dayList = list!
        }
    }
    func savePhoneFile(){
        let success = NSKeyedArchiver.archiveRootObject(dayList, toFile: BillCell.ArchiveURL.path)
        
        if !success {
            print("save file failed")
        }
    }
    func loadPhoneFile() ->[BillCell]? {
        return (NSKeyedUnarchiver.unarchiveObject(withFile: BillCell.ArchiveURL.path) as? [BillCell])
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "钢铁直男记账本"
        initDayList()
        self.tableView.rowHeight = 85
       
    }
    @IBAction func cancelToDay(segue: UIStoryboardSegue){
        if let addDayBillVC = segue.source as? SonViewController{
            if let addDayBill = addDayBillVC.billForEdit{
                if let selectedIndexPath = tableView.indexPathForSelectedRow{
                    dayList[(selectedIndexPath as NSIndexPath).row] = addDayBill
                    tableView.reloadRows(at: [selectedIndexPath], with: .none)
                }
                else{dayList.append(addDayBill)
                    let newIndexPath = IndexPath(row: dayList.count - 1, section: 0)
                    tableView.insertRows(at: [newIndexPath], with: .automatic)
                }
            }
            savePhoneFile()
        }
    }
    @IBAction func clearDate(segue: UIStoryboardSegue){
        dayList = [BillCell]()
        savePhoneFile()
        tableView.reloadData()
        
    }
    @IBAction func cancelAdd(segue: UIStoryboardSegue){
        
    }
    @IBAction func saveAdd(segue: UIStoryboardSegue){
        if let addDayBillVC = segue.source as? AddDayViewController{
            if let addDayBill = addDayBillVC.addForEdit{
                if let selectedIndexPath = tableView.indexPathForSelectedRow{
                    dayList[(selectedIndexPath as NSIndexPath).row] = addDayBill
                    tableView.reloadRows(at: [selectedIndexPath], with: .none)
                }
                else{
                    dayList.append(addDayBill)
                    /*let addDate = addDayBill.day!
                    let addYear = addDate.prefix(4)
                    let addMonth1 = addDate.index(addDate.startIndex, offsetBy: 5)
                    let addMonth2 = addDate.index(addDate.startIndex, offsetBy: 6)
                    let addDay1 = addDate.index(addDate.startIndex, offsetBy: 8)
                    let addDay2 = addDate.index(addDate.startIndex, offsetBy: 9)
                    let addMonth = addDate[addMonth1...addMonth2]
                    let addDay = addDate[addDay1...addDay2]
                    print(addYear)
                    print(addMonth)
                    print(addDay)*/
                    
                    let newIndexPath = IndexPath(row: dayList.count - 1, section: 0)
                    tableView.insertRows(at: [newIndexPath], with: .automatic)
                    
                }
                
            }
        }
        
    }
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        //print("tableView ::::: \(dayList.count)")
        return dayList.count
    }

   
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        print("tableView")
        if(dayList.count == 0){
            return UITableViewCell()
        }else{
        let cell = tableView.dequeueReusableCell(withIdentifier: "billCell", for: indexPath) as! HTableViewCell
        cell.dayText1?.text = dayList[indexPath.row].day
        cell.totalCostText1?.text = dayList[indexPath.row].totalCost
        let cost = Int(dayList[indexPath.row].totalCost!)!
        if(cost <= 20){
            cell.backgroundColor = UIColor(red: 180/255, green: 255/255, blue: 255/255, alpha: 1)
        }else if(cost >= 50)
        {
            cell.backgroundColor = UIColor(red: 255/255, green: 200/255, blue: 180/255, alpha: 1)
        }
        else{
            cell.backgroundColor = UIColor(red: 189/255, green: 252/255, blue: 201/255, alpha: 1)
        }
        // Configure the cell...
        return cell
        }
    }
    

    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            dayList.remove(at: indexPath.row)
            savePhoneFile()
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            dayList.remove(at: indexPath.row)
            savePhoneFile()
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */
*/


    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "Show"{
            let billVC = segue.destination as! SonViewController
            if let selectedCell = sender as? UITableViewCell{
                let indexPath = tableView.indexPath(for: selectedCell)
                let selectedBill = dayList[(indexPath as! NSIndexPath).row]
                billVC.billForEdit = selectedBill
            }
            print ("Show")
        }
        if (segue.identifier == "Add"){
            print("Add")
        }
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    

}
