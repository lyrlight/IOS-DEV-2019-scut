//
//  HTableViewCell.swift
//  Bill
//
//  Created by Apple on 2019/11/5.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class HTableViewCell: UITableViewCell {

    @IBOutlet weak var backgroundPicture1: UIImageView!
    @IBOutlet weak var totalCostText1: UILabel!
    @IBOutlet weak var dayText1: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
