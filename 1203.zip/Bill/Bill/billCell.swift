//
//  File.swift
//  Bill
//
//  Created by Apple on 2019/11/5.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation
class BillCell: NSObject,NSCoding{
    var day: String?
    var totalCost: String?
    var littleList: [LittleCell]?
    var weather: String?
    
  func encode(with aCoder: NSCoder) {
        aCoder.encode(day,forKey: "dayKey")
        aCoder.encode(totalCost, forKey: "totalCostKey")
        aCoder.encode(littleList, forKey:"littleKey")
        aCoder.encode(weather, forKey: "weatherKey")
    }
    required init?(coder aDecoder: NSCoder) {
        day = aDecoder.decodeObject(forKey: "dayKey")as? String
        totalCost = aDecoder.decodeObject(forKey: "totalCostKey")as? String
        littleList = aDecoder.decodeObject(forKey: "littleKey")as? [LittleCell]
        weather = aDecoder.decodeObject(forKey: "weatherKey")as? String
    }
 
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
   static let ArchiveURL = DocumentsDirectory.appendingPathComponent("dayList")

    init(day: String?, totalCost: String?, littleList: [LittleCell]?, weather: String?){
        self.day = day
        self.totalCost = totalCost
        self.littleList = littleList
        self.weather = weather
    }
}
