//
//  littleCell.swift
//  Bill
//
//  Created by Apple on 2019/11/12.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation
class LittleCell: NSObject, NSCoding{
    var time: String?
    var type: String?
    var number: String?
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(time, forKey: "timeKey")
        aCoder.encode(type, forKey: "typeKey")
        aCoder.encode(number, forKey: "numberKey")
    }
    
    required init?(coder aDecoder: NSCoder) {
        time = aDecoder.decodeObject(forKey: "timeKey")as? String
        type = aDecoder.decodeObject(forKey: "typeKey")as? String
        number = aDecoder.decodeObject(forKey: "numberKey")as? String
    }
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("littleList")

    init(time: String?, type: String?, number: String?) {
        self.time = time
        self.type = type
        self.number = number
    }
}
