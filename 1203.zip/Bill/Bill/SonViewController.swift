//
//  SonViewController.swift
//  Bill
//
//  Created by Apple on 2019/11/5.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class SonViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var count = 0
    var billForEdit: BillCell?
    var littleList:[LittleCell] = [LittleCell]()
    
    @IBAction func WeatherType(_ sender: Any) {
        let alertContorller1 = UIAlertController(title: "", message: "选择天气", preferredStyle: .alert)
        let cancelAction1 = UIAlertAction(title: "晴天", style: .default, handler: {
            action in
            self.weatherType.setTitle("晴天", for: UIControl.State.normal)
            self.weatherImg.image = UIImage(named: "晴天.jpg")
        })
        let cancelAction2 = UIAlertAction(title: "阴天", style: .default, handler: {
            action in
             self.weatherType.setTitle("阴天", for: UIControl.State.normal)
            self.weatherImg.image = UIImage(named: "阴天.jpg")
        })
        let cancelAction3 = UIAlertAction(title: "雨天", style: .default, handler: {
            action in
            self.weatherType.setTitle("雨天", for: UIControl.State.normal)
            self.weatherImg.image = UIImage(named: "雨天.jpg")
        })
        alertContorller1.addAction(cancelAction1)
        alertContorller1.addAction(cancelAction2)
        alertContorller1.addAction(cancelAction3)
        self.present(alertContorller1,animated: true,completion: nil)
    }
    @IBOutlet weak var weatherType: UIButton!
    @IBOutlet weak var weatherImg: UIImageView!
    @IBOutlet weak var littletableview: UITableView!
    @IBOutlet weak var totalcostText: UILabel!
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return littleList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "littleCell", for: indexPath)as! STableViewCell
        cell.timeText?.text = littleList[indexPath.row].time
        cell.typeText?.text = littleList[indexPath.row].type
        cell.numberText?.text = littleList[indexPath.row].number
        count += Int(littleList[indexPath.row].number!)!
        billForEdit?.totalCost=String(count)
        self.totalcostText.text = billForEdit?.totalCost

        return cell
    }

   
   
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = billForEdit?.day
        self.littleList = billForEdit!.littleList ?? [LittleCell]()
        self.weatherType.setTitle("晴天", for: UIControl.State.normal)
        if(self.weatherType.currentTitle == "晴天"){
            self.weatherImg.image = UIImage(named: "晴天.jpg")
        }
        else if(self.weatherType.currentTitle == "阴天"){
            self.weatherImg.image = UIImage(named: "阴天.jpg")
        }
        else{
            self.weatherImg.image = UIImage(named: "雨天.jpg")
        }
        littletableview.delegate = self
        littletableview.dataSource = self
        self.littletableview.rowHeight = 93.5
        // Do any additional setup after loading the view.
    }
    
    @IBAction func cancelThis(segue: UIStoryboardSegue){
        
    }
    @IBAction func saveThis(segue: UIStoryboardSegue){
        if let addDayBillVC = segue.source as? SelectViewController{
            if let addDayBill = addDayBillVC.dayForEdit{
                if let selectedIndexPath = littletableview.indexPathForSelectedRow{
                    littleList[(selectedIndexPath as NSIndexPath).row] = addDayBill
                    littletableview.reloadRows(at: [selectedIndexPath], with: .none)
                }
                else{littleList.append(addDayBill)
                    let newIndexPath = IndexPath(row: littleList.count - 1, section: 0)
                    littletableview.insertRows(at: [newIndexPath], with: .automatic)
                }
            }
        }
    }
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "cancelToDay"){
            billForEdit=BillCell(day: self.navigationItem.title!, totalCost: self.totalcostText.text,littleList: self.littleList,weather: weatherType.currentTitle)
            
            print("yes")
        }
        
    }
    


}
