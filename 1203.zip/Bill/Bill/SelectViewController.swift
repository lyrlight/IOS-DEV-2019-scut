//
//  SelectViewController.swift
//  Bill
//
//  Created by Apple on 2019/11/19.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class SelectViewController: UIViewController {
    var dayForEdit: LittleCell?
    
    @IBAction func timeAction(_ sender: Any) {
        let alertContorller1 = UIAlertController(title: "", message: "选择时间", preferredStyle: .alert)
        let cancelAction1 = UIAlertAction(title: "早上", style: .default, handler: {
            action in
            self.timeText.text = "早上"
        })
        let cancelAction2 = UIAlertAction(title: "中午", style: .default, handler: {
            action in
            self.timeText.text = "中午"
        })
        let cancelAction3 = UIAlertAction(title: "晚上", style: .default, handler: {
            action in
            self.timeText.text = "晚上"
        })
        alertContorller1.addAction(cancelAction1)
        alertContorller1.addAction(cancelAction2)
        alertContorller1.addAction(cancelAction3)
        self.present(alertContorller1,animated: true,completion: nil)
    
    
    }
    
    @IBOutlet weak var timeText: UILabel!
    
    
    @IBAction func typeAction(_ sender: Any) {
        let alertContorller1 = UIAlertController(title: "", message: "选择类型", preferredStyle: .alert)
        let cancelAction1 = UIAlertAction(title: "餐饮", style: .default, handler: {
            action in
            self.typeText.text = "餐饮"
        })
        let cancelAction2 = UIAlertAction(title: "娱乐", style: .default, handler: {
            action in
            self.typeText.text = "娱乐"
        })
        let cancelAction3 = UIAlertAction(title: "其他", style: .default, handler: {
            action in
            self.typeText.text = "其他"
        })
        alertContorller1.addAction(cancelAction1)
        alertContorller1.addAction(cancelAction2)
        alertContorller1.addAction(cancelAction3)
        self.present(alertContorller1,animated: true,completion: nil)
    }
    
    @IBOutlet weak var typeText: UILabel!
    
    @IBOutlet weak var number: UILabel!
    
    @IBOutlet weak var numberText: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

   
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "saveThis"){
            print("save")
            dayForEdit = LittleCell(time: self.timeText.text!, type: self.typeText.text!, number: self.numberText.text!)
        }
        else if(segue.identifier == "cancelThis"){
            print("cancel")
        }
    }


}
