//
//  AddDayViewController.swift
//  Bill
//
//  Created by Apple on 2019/11/26.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class AddDayViewController: UIViewController {
    var addForEdit: BillCell?
    var daypicker = UIDatePicker()
    var dayAndTime: String?
    @IBOutlet weak var picker: UIDatePicker!
    func getdate(){
        daypicker = self.view.viewWithTag(1) as! UIDatePicker
        let date = daypicker.date
        let dateFormater = DateFormatter()
        dateFormater.dateFormat = "yyyy年MM月dd日"
        dayAndTime = dateFormater.string(from: date)
        print(dayAndTime)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "saveAdd"){
            print("save")
            getdate()
            addForEdit = BillCell(day: dayAndTime, totalCost: "0",littleList: nil)
        }
        else if(segue.identifier == "cancelAdd"){
            print("cancel")
        }
    }

}
