//
//  HomeTableViewController.swift
//  Bill
//
//  Created by Apple on 2019/11/5.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class HomeTableViewController: UITableViewController{

    
    var dayList: [BillCell] = [BillCell]()
    func initDayList(){
       let list = loadPhoneFile()
        if(list == nil){
            var list1:[LittleCell]=[LittleCell]()
            list1.append(LittleCell(time: "早上", type: "123", number: "2314"))
            dayList.append(BillCell(day: "2019年11月1日", totalCost: "50",littleList: list1 ))
        }else{
            dayList = list!
        }
    }
    func savePhoneFile(){
        let success = NSKeyedArchiver.archiveRootObject(dayList, toFile: BillCell.ArchiveURL.path)
        
        if !success {
            print("failed")
        }
    }
    func loadPhoneFile() ->[BillCell]? {
        return (NSKeyedUnarchiver.unarchiveObject(withFile: BillCell.ArchiveURL.path) as? [BillCell])
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        initDayList()
        self.tableView.rowHeight = 85
       
    }
    @IBAction func cancelToDay(segue: UIStoryboardSegue){
        if let addDayBillVC = segue.source as? SonViewController{
            if let addDayBill = addDayBillVC.billForEdit{
                if let selectedIndexPath = tableView.indexPathForSelectedRow{
                    dayList[(selectedIndexPath as NSIndexPath).row] = addDayBill
                    tableView.reloadRows(at: [selectedIndexPath], with: .none)
                }
                else{dayList.append(addDayBill)
                    let newIndexPath = IndexPath(row: dayList.count - 1, section: 0)
                    tableView.insertRows(at: [newIndexPath], with: .automatic)
                }
            }
        savePhoneFile()
        }
    }
    @IBAction func cancelAdd(segue: UIStoryboardSegue){
        
    }
    @IBAction func saveAdd(segue: UIStoryboardSegue){
        if let addDayBillVC = segue.source as? AddDayViewController{
            if let addDayBill = addDayBillVC.addForEdit{
                if let selectedIndexPath = tableView.indexPathForSelectedRow{
                    dayList[(selectedIndexPath as NSIndexPath).row] = addDayBill
                    tableView.reloadRows(at: [selectedIndexPath], with: .none)
                }
                else{
                    dayList.append(addDayBill)
                    let newIndexPath = IndexPath(row: dayList.count - 1, section: 0)
                    tableView.insertRows(at: [newIndexPath], with: .automatic)
                }
                
            }
        }
    }
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return dayList.count
    }

   
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "billCell", for: indexPath) as! HTableViewCell
        cell.dayText1?.text = dayList[indexPath.row].day
        cell.totalCostText1?.text = dayList[indexPath.row].totalCost

        // Configure the cell...

        return cell
    }
    

    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            dayList.remove(at: indexPath.row)
            savePhoneFile()
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            dayList.remove(at: indexPath.row)
            savePhoneFile()
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */
*/


    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "Show"{
            let billVC = segue.destination as! SonViewController
            if let selectedCell = sender as? UITableViewCell{
                let indexPath = tableView.indexPath(for: selectedCell)
                let selectedBill = dayList[(indexPath as! NSIndexPath).row]
                billVC.billForEdit = selectedBill
            }
            print ("Show")
        }
        if (segue.identifier == "Add"){
            print("Add")
        }
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    

}
