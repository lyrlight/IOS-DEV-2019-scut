//
//  STableViewCell.swift
//  Bill
//
//  Created by Apple on 2019/11/12.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class STableViewCell: UITableViewCell {

    @IBOutlet weak var timeText: UILabel!
    @IBOutlet weak var typeText: UILabel!
    @IBOutlet weak var numberText: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
