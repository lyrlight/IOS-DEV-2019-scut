//
//  File.swift
//  Bill
//
//  Created by Apple on 2019/11/5.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation
class BillCell {
    var day: String?
    var totalCost: String?
/*   func encode(with aCoder: NSCoder) {
        aCoder.encode(day,forKey: "dayKey")
        aCoder.encode(totalCost, forKey: "totalCostKey")
    }
    required init?(coder aDecoder: NSCoder) {
        day = aDecoder.decodeObject(forKey: "dayKey")as? String
        totalCost = aDecoder.decodeObject(forKey: "totalCostKey")as? String
    }
 */
 //   static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
 //   static let ArchiveURL = DocumentsDirectory.appendingPathComponent("dayList")

    init(day: String?, totalCost: String?){
        self.day = day
        self.totalCost = totalCost
    }
}
