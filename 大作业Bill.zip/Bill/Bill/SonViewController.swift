//
//  SonViewController.swift
//  Bill
//
//  Created by Apple on 2019/11/5.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class SonViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    
    
    @IBOutlet weak var littletableview: UITableView!
    @IBOutlet weak var totalcostText: UILabel!
    
    var littleList: [LittleCell] = [LittleCell]()
    func initLittleList(){
        littleList.append(LittleCell(time: "早上", type: "餐饮", number: "10"))
        littleList.append(LittleCell(time: "早上", type: "餐饮", number: "30"))
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return littleList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "littleCell", for: indexPath)as! STableViewCell
        cell.timeText?.text = littleList[indexPath.row].time
        cell.typeText?.text = littleList[indexPath.row].type
        cell.numberText?.text = littleList[indexPath.row].number
        count += Int(littleList[indexPath.row].number!)!
        billForEdit?.totalCost=String(count)
        self.totalcostText.text = billForEdit?.totalCost
        return cell
    }

    var count = 0
    var billForEdit: BillCell?
   
    override func viewDidLoad() {
        super.viewDidLoad()
        initLittleList()
        self.navigationItem.title = billForEdit?.day
        littletableview.delegate = self
        littletableview.dataSource = self
        self.littletableview.rowHeight = 93.5
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        
    }
    */

    @IBAction func cancelToDay(segue: UIStoryboardSegue){
        
    }

}
