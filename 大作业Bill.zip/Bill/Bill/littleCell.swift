//
//  littleCell.swift
//  Bill
//
//  Created by Apple on 2019/11/12.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation
class LittleCell{
    var time: String?
    var type: String?
    var number: String?
    init(time: String?, type: String?, number: String?) {
        self.time = time
        self.type = type
        self.number = number
    }
}
