//
//  ViewController.swift
//  111
//
//  Created by Apple on 2019/9/24.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var a=false
    var b=false
    var c=false
    var d=false
    var lab1: String = " "
    var lab2: String = " "
    var lab3: String = " "
    var lab4: String = " "
    override func viewDidLoad() {
        super.viewDidLoad()
        label2.isHidden=true; label1.text="以下四个图片各自为什么色"
        // Do any additional setup after loading the view.
    }
    
    
    @IBOutlet weak var label1: UILabel!
    
  
    @IBOutlet weak var text4: UITextField!
    @IBOutlet weak var text3: UITextField!
    @IBOutlet weak var text: UITextField!
    
    @IBOutlet weak var text2: UITextField!
 
    @IBOutlet weak var label2: UILabel!
        
    @IBAction func button(_ sender: Any) {
    
    if (text.text=="blue")
        {
            a=true
        }
        else{
            lab1="第一个错误"
        a=false
        }
        if (text2.text=="green")
        {
            b=true
        }
        else{
            lab2="第二个错误"
            b=false
        }
        if (text3.text=="black")
        {
            c=true
        }
        else{
            c=false
            lab3="第三个错误"
        }
        if (text4.text=="red")
        {
            d=true
        }
        else{
            d=false
            lab4="第四个错误"
        }
        
       label2.isHidden=false
        if(a==true&&b==true&&c==true&&d==true){
            label2.text="恭喜你全部回答正确"
        }
        else
        {label2.text="\(lab1)\(lab2)\(lab3)\(lab4)"
        
        }
    }
}

