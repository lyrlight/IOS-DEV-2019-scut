//
//  AboutViewController.swift
//  Bill
//
//  Created by Apple on 2019/12/10.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class AboutViewController: UIViewController {

    
    @IBOutlet weak var headPicture: UIImageView!
    override func viewDidLoad() {
        self.headPicture.image = UIImage(named: "head.png")
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

   
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
  /* override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
       
            /*if segue.identifier == "Show"{
                let billVC = segue.destination as! SonViewController
                if let selectedCell = sender as? UITableViewCell{
                    let indexPath = tableView.indexPath(for: selectedCell)
                    let selectedBill = dayList[(indexPath as! NSIndexPath).row]
                    billVC.billForEdit = selectedBill
                }
                print ("Show")
            }*/
    }
 */
}
