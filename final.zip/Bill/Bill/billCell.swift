//
//  File.swift
//  Bill
//
//  Created by Apple on 2019/11/5.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation
import UIKit
class BillCell: NSObject,NSCoding{
    var day: String?
    var totalCost: String?
    var littleList: [LittleCell]?
    var weather: String?
    var weatherImage: UIImage?
    
  func encode(with aCoder: NSCoder) {
        aCoder.encode(day,forKey: "dayKey")
        aCoder.encode(totalCost, forKey: "totalCostKey")
        aCoder.encode(littleList, forKey:"littleKey")
        aCoder.encode(weather, forKey: "weatherKey")
        aCoder.encode(weatherImage, forKey: "imageKey")
    }
    required init?(coder aDecoder: NSCoder) {
        day = aDecoder.decodeObject(forKey: "dayKey")as? String
        totalCost = aDecoder.decodeObject(forKey: "totalCostKey")as? String
        littleList = aDecoder.decodeObject(forKey: "littleKey")as? [LittleCell]
        weather = aDecoder.decodeObject(forKey: "weatherKey")as? String
        weatherImage = aDecoder.decodeObject(forKey: "imageKey")as? UIImage
    }
 
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
   static let ArchiveURL = DocumentsDirectory.appendingPathComponent("dayList")

    init(day: String?, totalCost: String?, littleList: [LittleCell]?, weather: String?, weatherImage: UIImage?){
        self.day = day
        self.totalCost = totalCost
        self.littleList = littleList
        self.weather = weather
        self.weatherImage = weatherImage
    }
}
