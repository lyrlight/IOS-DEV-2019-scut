//
//  SonViewController.swift
//  Bill
//
//  Created by Apple on 2019/11/5.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class SonViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var count = 0
    var billForEdit: BillCell?
    
    @IBOutlet weak var littletableview: UITableView!
    @IBOutlet weak var totalcostText: UILabel!
    
    var littleList:[LittleCell] = [LittleCell]()
    func initLittleList(){
        littleList=billForEdit!.littleList
        littleList = loadPhoneFile()!
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return littleList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "littleCell", for: indexPath)as! STableViewCell
        cell.timeText?.text = littleList[indexPath.row].time
        cell.typeText?.text = littleList[indexPath.row].type
        cell.numberText?.text = littleList[indexPath.row].number
        count += Int(littleList[indexPath.row].number!)!
        billForEdit?.totalCost=String(count)
        self.totalcostText.text = billForEdit?.totalCost

        return cell
    }

   
   
    override func viewDidLoad() {
        super.viewDidLoad()
        initLittleList()
        self.navigationItem.title = billForEdit?.day
        littletableview.delegate = self
        littletableview.dataSource = self
        self.littletableview.rowHeight = 93.5
        // Do any additional setup after loading the view.
    }
    
    @IBAction func cancelThis(segue: UIStoryboardSegue){
        
    }
    @IBAction func saveThis(segue: UIStoryboardSegue){
        if let addDayBillVC = segue.source as? SelectViewController{
            if let addDayBill = addDayBillVC.dayForEdit{
                if let selectedIndexPath = littletableview.indexPathForSelectedRow{
                    littleList[(selectedIndexPath as NSIndexPath).row] = addDayBill
                    littletableview.reloadRows(at: [selectedIndexPath], with: .none)
                }
                else{littleList.append(addDayBill)
                    let newIndexPath = IndexPath(row: littleList.count - 1, section: 0)
                    littletableview.insertRows(at: [newIndexPath], with: .automatic)
                }
                savePhoneFile()
            }
        }
    }
    func savePhoneFile(){
        let success = NSKeyedArchiver.archiveRootObject(littleList, toFile: LittleCell.ArchiveURL.path)
        
        if !success {
            print("failed")
        }
    }
    func loadPhoneFile()->[LittleCell]?{
             return (NSKeyedUnarchiver.unarchiveObject(withFile: LittleCell.ArchiveURL.path) as? [LittleCell])
    }
    
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "cancelToDay"){
        billForEdit=BillCell(day: self.navigationItem.title!, totalCost: self.totalcostText.text)
            
            print("yes")
        }
        
    }
    


}
